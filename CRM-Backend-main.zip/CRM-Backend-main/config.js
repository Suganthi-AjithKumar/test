// module.exports = dbcon = {
//   host: "localhost",
//   user: "root",
//   password: "",
//   database: "crm_demo",
// };

module.exports = dbcon = {
  host: "localhost",
  user: "swathawv_Crm",
  password: "qP9cL6pm;U(M",
  port:3306,
  database: "swathawv_CRM_BACKEND",
};
