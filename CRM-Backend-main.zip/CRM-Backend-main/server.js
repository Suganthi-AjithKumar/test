const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
var jwt = require("jsonwebtoken");
require("dotenv").config();
const port = process.env.PORT || 8000;

//import

const {
  masterRoutes,
  marketingRoutes,
  salesRoutes,
  LoginRoute,
  customerRoutes,
  serviceRoutes,
  RdRoutes,
  accountRoutes,
  reportRoutes,
  Approval,
  NotificationRoute,
} = require("./Routes/router");
const db = require("./Config/db");

app.use(bodyParser.json({ limit: "2000mb" }));
app.use(bodyParser.urlencoded({ limit: "2000mb", extended: true }));
app.use(cors());

app.get("/", function (req, res) {
  res.send("CRM Server Running Successfully");
});

//Database connection
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("DB Connected!");
});

// Session Check

var Sessioncheck = async function (req, res, next) {
  var sessionObj = req.headers; //get data from sessionobj it present or not
  if (sessionObj && sessionObj["access_token"]) {
    jwt.verify(
      sessionObj["access_token"],
      process.env.SECUREKEY || "CRM_API_2022",
      function (err, decoded) {
        //verify the session token its true than execute once session expeired it execute
        if (err) {
          res.status(401).json({
            status: false,
            message: "Token expired",
          });
        } else {
          next(); //it is also same as return function
        }
      }
    );
  } else {
    res.status(401).json({
      status: false,
      message: "Unauthorized Access",
    });
  }
};

// Routes
app.use("/master", masterRoutes);
app.use("/marketing", marketingRoutes);
app.use("/sales", salesRoutes);
app.use("/session", LoginRoute);
app.use("/support", customerRoutes);
app.use("/services", serviceRoutes);
app.use("/rd", RdRoutes);
app.use("/accounts", accountRoutes);
app.use("/report", reportRoutes);
app.use("/approv", Approval);
app.use("/", NotificationRoute);

// server connection
app.listen(port, function (err, success) {
  if (err) {
    throw err;
  }
  console.log(`CRM app listening at http://localhost:${port}`);
});
